# Code Citations

## License: unknown
https://github.com/freyhill/freyhill.github.io/tree/93ff85076768e97a60b21dd49bebd8a681a5a912/example/currying/index.html

```
.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"
```

## Acknowledgments

This project uses external code and resources. See [CodeCitations.md](CodeCitations.md) for details.

