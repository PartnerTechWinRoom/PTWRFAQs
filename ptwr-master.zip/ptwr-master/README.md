# Azure Table Viewer

This project is a static website that reads data from an Azure Table and displays the content in a grid format. It is designed to provide a simple interface for viewing Azure Table data.

## Project Structure

```
azure-table-viewer
|
├── index.html # Main HTML document 
├── src
│   ├── styles
│   │   └── style.css     # Styles for the website
│   └── scripts
│       └── app.js        # JavaScript for fetching and displaying data
├── package.json          # npm configuration file
├── README.md             # Project documentation
└── .gitignore            # Git ignore file
```

## Setup Instructions

1. **Clone the repository:**
   ```
   git clone https://github.com/yourusername/azure-table-viewer.git
   cd azure-table-viewer
   ```

2. **Install dependencies:**
   ```
   npm install
   ```

3. **Run the application:**
   Open `src/index.html` in your web browser to view the application.

## Usage

- The application will automatically fetch data from the specified Azure Table and display it in a grid format.
- Ensure that you have the correct permissions and connection strings set up to access your Azure Table.

## Contributing

If you would like to contribute to this project, please fork the repository and submit a pull request with your changes.

## License

This project is licensed under the MIT License. See the LICENSE file for more details.